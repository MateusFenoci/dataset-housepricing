BASE_URL = 'https://www.quintoandar.com.br/alugar/imovel/belo-horizonte-mg-brasil'
BASE_HTML = 'data/raw/links.html'